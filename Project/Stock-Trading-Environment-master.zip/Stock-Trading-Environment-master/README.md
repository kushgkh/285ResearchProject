# Stock-Trading-Environment
A custom OpenAI gym environment for simulating stock trades on historical price data.

If you'd like to learn about creating custom OpenAI gym environments, check out the Medium article: https://medium.com/@adamjking3/creating-a-custom-openai-gym-environment-for-stock-trading-be532be3910e
